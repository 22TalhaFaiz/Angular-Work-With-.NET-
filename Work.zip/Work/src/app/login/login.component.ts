import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiDataService } from '../api-data.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule,HttpClientModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
  providers:[ApiDataService]
})
export class LoginComponent {

  constructor (private Loginw : ApiDataService, private route : Router){


  }

  user = {
    email : '',
    password : '',

  }

  abc(){
    this.Loginw.login(this.user).subscribe((data:any) => {
      if(data.success){
        this.route.navigate(['fetchpage']);

      }
      else{
        alert("Invalid Credientals");
        this.user = {email : '' ,  password : ''}
      }
    })

    }
  }




