import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { ApplicationConfig, provideZoneChangeDetection, Component } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { LoginComponent } from './login/login.component';


export const appConfig: ApplicationConfig = {
  providers: [provideZoneChangeDetection({ eventCoalescing: true }), provideRouter(
    [
      {
        path:'',redirectTo:'Login',pathMatch:'full'
      },
    {
      path:'fetchpage',component:FetchDataComponent
    },
    {
      path:'Login',component:LoginComponent
    }


    ]



    )]
};
