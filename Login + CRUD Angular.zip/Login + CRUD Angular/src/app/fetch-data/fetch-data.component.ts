import { Component } from '@angular/core';
import { ApiDataService } from '../api-data.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-fetch-data',
  standalone: true,
  imports: [FormsModule,HttpClientModule,CommonModule,RouterLink],
  templateUrl: './fetch-data.component.html',
  styleUrl: './fetch-data.component.css',
  providers:[ApiDataService]
})
export class FetchDataComponent {
  public xyz : any;

  public selected : any;

  constructor(private api : ApiDataService){

  }
  ngOnInit() {
this.api.GetApi().subscribe(getdata =>{
  this.xyz = getdata;
  console.log(getdata);
})
}

editdata(abc:any){
  this.selected = abc;
}

updatedata(){
  this.api.xyz(this.selected).subscribe(data => {
    console.log(data);
    this.selected = null;
  })
}
deletedata(id:number){
  if(confirm("Are You Sure You Want To Delete?")){
    this.api.deleteuser(id).subscribe(data =>{
      this.ngOnInit();
    })
  }
}



}
