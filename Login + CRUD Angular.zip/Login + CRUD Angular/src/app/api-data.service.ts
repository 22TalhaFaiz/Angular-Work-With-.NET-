import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiDataService {

  private url = 'https://localhost:7213/Home';

  private url2 = 'https://localhost:7213/New';

  constructor(private api : HttpClient) {
  }
  GetApi(){
   return this.api.get('https://localhost:7213/Home')
  }

  xyz(data:any){
    return this.api.put(`${this.url}/Updateuser`,data);
  }

  deleteuser(id:number){
    return this.api.delete(`${this.url}/delete`,{body:{id}})
  }

  fileupload(data:any)
  {
    return this.api.post(this.url2,data);

  }
  login(userdata:any){
    return this.api.post(`${this.url2}/login`,userdata);
  }

}

