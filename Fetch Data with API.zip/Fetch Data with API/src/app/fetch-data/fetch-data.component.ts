import { Component } from '@angular/core';
import { ApiDataService } from '../api-data.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-fetch-data',
  standalone: true,
  imports: [FormsModule,HttpClientModule,CommonModule],
  templateUrl: './fetch-data.component.html',
  styleUrl: './fetch-data.component.css',
  providers:[ApiDataService]
})
export class FetchDataComponent {
  public xyz : any;

  constructor(private api : ApiDataService){

  }
  ngOnInit() {
this.api.GetApi().subscribe(getdata =>{
  this.xyz = getdata;
  console.log(getdata);
})

  }


}
