import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiDataService {

  constructor(private api : HttpClient) {
  }
  GetApi(){
   return this.api.get('https://localhost:7020/Home/Index')
  }
}
