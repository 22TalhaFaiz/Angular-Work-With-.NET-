using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
  public class HomeController : Controller
  {

    Connection mydb = new Connection();

    public IActionResult Index()
    {
      var data = mydb.Users.ToList();
      return Ok(data);
    }

    public IActionResult Privacy()
    {
      return View();
    }



  }
}
